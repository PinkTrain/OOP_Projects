﻿namespace Project_9_BusDriverDB
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label modelLabel;
            System.Windows.Forms.Label mileageLabel;
            this.busDriverDataSet = new Project_9_BusDriverDB.BusDriverDataSet();
            this.busBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.busTableAdapter = new Project_9_BusDriverDB.BusDriverDataSetTableAdapters.BusTableAdapter();
            this.tableAdapterManager = new Project_9_BusDriverDB.BusDriverDataSetTableAdapters.TableAdapterManager();
            this.driverTableAdapter = new Project_9_BusDriverDB.BusDriverDataSetTableAdapters.DriverTableAdapter();
            this.driverBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.modelTextBox = new System.Windows.Forms.TextBox();
            this.mileageTextBox = new System.Windows.Forms.TextBox();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.driverDataGridView = new System.Windows.Forms.DataGridView();
            this.busNoToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.busNoToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.find_this_busToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.find_this_busToolStrip = new System.Windows.Forms.ToolStrip();
            modelLabel = new System.Windows.Forms.Label();
            mileageLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.busDriverDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.busBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.driverBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.driverDataGridView)).BeginInit();
            this.find_this_busToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // busDriverDataSet
            // 
            this.busDriverDataSet.DataSetName = "BusDriverDataSet";
            this.busDriverDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // busBindingSource
            // 
            this.busBindingSource.DataMember = "Bus";
            this.busBindingSource.DataSource = this.busDriverDataSet;
            // 
            // busTableAdapter
            // 
            this.busTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BusModelTableAdapter = null;
            this.tableAdapterManager.BusTableAdapter = this.busTableAdapter;
            this.tableAdapterManager.CandidateTableAdapter = null;
            this.tableAdapterManager.DriverTableAdapter = this.driverTableAdapter;
            this.tableAdapterManager.UpdateOrder = Project_9_BusDriverDB.BusDriverDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // driverTableAdapter
            // 
            this.driverTableAdapter.ClearBeforeFill = true;
            // 
            // driverBindingSource
            // 
            this.driverBindingSource.DataMember = "BusDriver";
            this.driverBindingSource.DataSource = this.busBindingSource;
            // 
            // modelTextBox
            // 
            this.modelTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.busBindingSource, "Model", true));
            this.modelTextBox.Location = new System.Drawing.Point(998, 106);
            this.modelTextBox.Name = "modelTextBox";
            this.modelTextBox.Size = new System.Drawing.Size(100, 31);
            this.modelTextBox.TabIndex = 6;
            // 
            // modelLabel
            // 
            modelLabel.AutoSize = true;
            modelLabel.Location = new System.Drawing.Point(898, 109);
            modelLabel.Name = "modelLabel";
            modelLabel.Size = new System.Drawing.Size(77, 25);
            modelLabel.TabIndex = 5;
            modelLabel.Text = "Model:";
            // 
            // mileageTextBox
            // 
            this.mileageTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.busBindingSource, "Mileage", true));
            this.mileageTextBox.Location = new System.Drawing.Point(204, 106);
            this.mileageTextBox.Name = "mileageTextBox";
            this.mileageTextBox.Size = new System.Drawing.Size(100, 31);
            this.mileageTextBox.TabIndex = 4;
            // 
            // mileageLabel
            // 
            mileageLabel.AutoSize = true;
            mileageLabel.Location = new System.Drawing.Point(104, 109);
            mileageLabel.Name = "mileageLabel";
            mileageLabel.Size = new System.Drawing.Size(94, 25);
            mileageLabel.TabIndex = 3;
            mileageLabel.Text = "Mileage:";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "BusNo";
            this.dataGridViewTextBoxColumn4.HeaderText = "BusNo";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Age";
            this.dataGridViewTextBoxColumn3.HeaderText = "Age";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "DriverID";
            this.dataGridViewTextBoxColumn1.HeaderText = "DriverID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // driverDataGridView
            // 
            this.driverDataGridView.AutoGenerateColumns = false;
            this.driverDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.driverDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.driverDataGridView.DataSource = this.driverBindingSource;
            this.driverDataGridView.Location = new System.Drawing.Point(107, 184);
            this.driverDataGridView.Name = "driverDataGridView";
            this.driverDataGridView.RowTemplate.Height = 33;
            this.driverDataGridView.Size = new System.Drawing.Size(991, 344);
            this.driverDataGridView.TabIndex = 7;
            // 
            // busNoToolStripLabel
            // 
            this.busNoToolStripLabel.Name = "busNoToolStripLabel";
            this.busNoToolStripLabel.Size = new System.Drawing.Size(90, 36);
            this.busNoToolStripLabel.Text = "BusNo:";
            // 
            // busNoToolStripTextBox
            // 
            this.busNoToolStripTextBox.Name = "busNoToolStripTextBox";
            this.busNoToolStripTextBox.Size = new System.Drawing.Size(100, 39);
            // 
            // find_this_busToolStripButton
            // 
            this.find_this_busToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.find_this_busToolStripButton.Name = "find_this_busToolStripButton";
            this.find_this_busToolStripButton.Size = new System.Drawing.Size(161, 36);
            this.find_this_busToolStripButton.Text = "Find_this_bus";
            this.find_this_busToolStripButton.Click += new System.EventHandler(this.find_this_busToolStripButton_Click_1);
            // 
            // find_this_busToolStrip
            // 
            this.find_this_busToolStrip.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.find_this_busToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.busNoToolStripLabel,
            this.busNoToolStripTextBox,
            this.find_this_busToolStripButton});
            this.find_this_busToolStrip.Location = new System.Drawing.Point(0, 0);
            this.find_this_busToolStrip.Name = "find_this_busToolStrip";
            this.find_this_busToolStrip.Size = new System.Drawing.Size(1208, 39);
            this.find_this_busToolStrip.TabIndex = 8;
            this.find_this_busToolStrip.Text = "find_this_busToolStrip";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1208, 623);
            this.Controls.Add(this.find_this_busToolStrip);
            this.Controls.Add(this.driverDataGridView);
            this.Controls.Add(mileageLabel);
            this.Controls.Add(this.mileageTextBox);
            this.Controls.Add(modelLabel);
            this.Controls.Add(this.modelTextBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.busDriverDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.busBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.driverBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.driverDataGridView)).EndInit();
            this.find_this_busToolStrip.ResumeLayout(false);
            this.find_this_busToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BusDriverDataSet busDriverDataSet;
        private System.Windows.Forms.BindingSource busBindingSource;
        private BusDriverDataSetTableAdapters.BusTableAdapter busTableAdapter;
        private BusDriverDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private BusDriverDataSetTableAdapters.DriverTableAdapter driverTableAdapter;
        private System.Windows.Forms.BindingSource driverBindingSource;
        private System.Windows.Forms.TextBox modelTextBox;
        private System.Windows.Forms.TextBox mileageTextBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridView driverDataGridView;
        private System.Windows.Forms.ToolStripLabel busNoToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox busNoToolStripTextBox;
        private System.Windows.Forms.ToolStripButton find_this_busToolStripButton;
        private System.Windows.Forms.ToolStrip find_this_busToolStrip;
    }
}