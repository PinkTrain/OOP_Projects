﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_9_BusDriverDB
{
    class BusModel
    {
        public string BusNo { get; set; }
        public string ModelCode { get; set; }
        public int Mileage { get; set; }

        public string Detail()
        {
            return BusNo + " - " + Mileage.ToString() + " - " + ModelCode; 
        }
    }
}
