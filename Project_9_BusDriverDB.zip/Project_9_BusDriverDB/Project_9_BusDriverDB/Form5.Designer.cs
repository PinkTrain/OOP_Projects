﻿namespace Project_9_BusDriverDB
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtEnterAge = new System.Windows.Forms.TextBox();
            this.btnFindCandidates = new System.Windows.Forms.Button();
            this.btnAddCandidates = new System.Windows.Forms.Button();
            this.lstFindCandidates = new System.Windows.Forms.ListBox();
            this.lstAddCandidates = new System.Windows.Forms.ListBox();
            this.lstAssignBuses = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnAssignBuses = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(388, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter an age (e.g. 27, 49, etc): ";
            // 
            // txtEnterAge
            // 
            this.txtEnterAge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtEnterAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEnterAge.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtEnterAge.Location = new System.Drawing.Point(513, 66);
            this.txtEnterAge.Name = "txtEnterAge";
            this.txtEnterAge.Size = new System.Drawing.Size(100, 38);
            this.txtEnterAge.TabIndex = 1;
            this.txtEnterAge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEnterAge_KeyPress);
            // 
            // btnFindCandidates
            // 
            this.btnFindCandidates.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFindCandidates.Location = new System.Drawing.Point(30, 189);
            this.btnFindCandidates.Name = "btnFindCandidates";
            this.btnFindCandidates.Size = new System.Drawing.Size(459, 47);
            this.btnFindCandidates.TabIndex = 2;
            this.btnFindCandidates.Text = "Find candidates not older than this age";
            this.btnFindCandidates.UseVisualStyleBackColor = true;
            this.btnFindCandidates.Click += new System.EventHandler(this.btnFindCandidates_Click);
            // 
            // btnAddCandidates
            // 
            this.btnAddCandidates.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCandidates.Location = new System.Drawing.Point(513, 189);
            this.btnAddCandidates.Name = "btnAddCandidates";
            this.btnAddCandidates.Size = new System.Drawing.Size(526, 47);
            this.btnAddCandidates.TabIndex = 3;
            this.btnAddCandidates.Text = "Add candidates found into the Driver Table";
            this.btnAddCandidates.UseVisualStyleBackColor = true;
            this.btnAddCandidates.Click += new System.EventHandler(this.btnAddCandidates_Click);
            // 
            // lstFindCandidates
            // 
            this.lstFindCandidates.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstFindCandidates.FormattingEnabled = true;
            this.lstFindCandidates.ItemHeight = 29;
            this.lstFindCandidates.Location = new System.Drawing.Point(30, 251);
            this.lstFindCandidates.Name = "lstFindCandidates";
            this.lstFindCandidates.Size = new System.Drawing.Size(459, 439);
            this.lstFindCandidates.TabIndex = 4;
            // 
            // lstAddCandidates
            // 
            this.lstAddCandidates.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstAddCandidates.FormattingEnabled = true;
            this.lstAddCandidates.ItemHeight = 29;
            this.lstAddCandidates.Location = new System.Drawing.Point(523, 242);
            this.lstAddCandidates.Name = "lstAddCandidates";
            this.lstAddCandidates.Size = new System.Drawing.Size(602, 439);
            this.lstAddCandidates.TabIndex = 5;
            // 
            // lstAssignBuses
            // 
            this.lstAssignBuses.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstAssignBuses.FormattingEnabled = true;
            this.lstAssignBuses.ItemHeight = 29;
            this.lstAssignBuses.Location = new System.Drawing.Point(1142, 251);
            this.lstAssignBuses.Name = "lstAssignBuses";
            this.lstAssignBuses.Size = new System.Drawing.Size(602, 439);
            this.lstAssignBuses.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(25, 710);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(376, 29);
            this.label2.TabIndex = 7;
            this.label2.Text = "(This list shows candidates found)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(508, 710);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(515, 26);
            this.label3.TabIndex = 8;
            this.label3.Text = "(This list shows Driver table after adding candidates)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(1127, 710);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(647, 26);
            this.label4.TabIndex = 9;
            this.label4.Text = "(This list shows all candidates in Driver table after assigned a bus)";
            // 
            // btnAssignBuses
            // 
            this.btnAssignBuses.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAssignBuses.Location = new System.Drawing.Point(1142, 189);
            this.btnAssignBuses.Name = "btnAssignBuses";
            this.btnAssignBuses.Size = new System.Drawing.Size(546, 47);
            this.btnAssignBuses.TabIndex = 10;
            this.btnAssignBuses.Text = "Assign buses to all candidates in Driver Table";
            this.btnAssignBuses.UseVisualStyleBackColor = true;
            this.btnAssignBuses.Click += new System.EventHandler(this.btnAssignBuses_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1251, 41);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(341, 75);
            this.label5.TabIndex = 11;
            this.label5.Text = "*Assign to bus \'A01\', if age <= 40 \r\n\r\n*Assign to bus \'C55, all other ages";
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(192F, 192F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1817, 803);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnAssignBuses);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lstAssignBuses);
            this.Controls.Add(this.lstAddCandidates);
            this.Controls.Add(this.lstFindCandidates);
            this.Controls.Add(this.btnAddCandidates);
            this.Controls.Add(this.btnFindCandidates);
            this.Controls.Add(this.txtEnterAge);
            this.Controls.Add(this.label1);
            this.Name = "Form5";
            this.Text = "Form5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtEnterAge;
        private System.Windows.Forms.Button btnFindCandidates;
        private System.Windows.Forms.Button btnAddCandidates;
        private System.Windows.Forms.ListBox lstFindCandidates;
        private System.Windows.Forms.ListBox lstAddCandidates;
        private System.Windows.Forms.ListBox lstAssignBuses;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnAssignBuses;
        private System.Windows.Forms.Label label5;
    }
}