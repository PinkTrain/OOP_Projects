﻿namespace Project_9_BusDriverDB
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label modelCodeLabel;
            System.Windows.Forms.Label mileageLabel;
            this.busDriverDataSet = new Project_9_BusDriverDB.BusDriverDataSet();
            this.busModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.busModelTableAdapter = new Project_9_BusDriverDB.BusDriverDataSetTableAdapters.BusModelTableAdapter();
            this.tableAdapterManager = new Project_9_BusDriverDB.BusDriverDataSetTableAdapters.TableAdapterManager();
            this.busTableAdapter = new Project_9_BusDriverDB.BusDriverDataSetTableAdapters.BusTableAdapter();
            this.cboModelCode = new System.Windows.Forms.ComboBox();
            this.busBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txtMileage = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lstResult = new System.Windows.Forms.ListBox();
            modelCodeLabel = new System.Windows.Forms.Label();
            mileageLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.busDriverDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.busModelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.busBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // modelCodeLabel
            // 
            modelCodeLabel.AutoSize = true;
            modelCodeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            modelCodeLabel.Location = new System.Drawing.Point(184, 61);
            modelCodeLabel.Name = "modelCodeLabel";
            modelCodeLabel.Size = new System.Drawing.Size(112, 37);
            modelCodeLabel.TabIndex = 1;
            modelCodeLabel.Text = "Model:";
            // 
            // mileageLabel
            // 
            mileageLabel.AutoSize = true;
            mileageLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            mileageLabel.Location = new System.Drawing.Point(68, 140);
            mileageLabel.Name = "mileageLabel";
            mileageLabel.Size = new System.Drawing.Size(228, 37);
            mileageLabel.TabIndex = 5;
            mileageLabel.Text = "Mileage below:";
            // 
            // busDriverDataSet
            // 
            this.busDriverDataSet.DataSetName = "BusDriverDataSet";
            this.busDriverDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // busModelBindingSource
            // 
            this.busModelBindingSource.DataMember = "BusModel";
            this.busModelBindingSource.DataSource = this.busDriverDataSet;
            // 
            // busModelTableAdapter
            // 
            this.busModelTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BusModelTableAdapter = this.busModelTableAdapter;
            this.tableAdapterManager.BusTableAdapter = this.busTableAdapter;
            this.tableAdapterManager.CandidateTableAdapter = null;
            this.tableAdapterManager.DriverTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Project_9_BusDriverDB.BusDriverDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // busTableAdapter
            // 
            this.busTableAdapter.ClearBeforeFill = true;
            // 
            // cboModelCode
            // 
            this.cboModelCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.busModelBindingSource, "ModelCode", true));
            this.cboModelCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboModelCode.FormattingEnabled = true;
            this.cboModelCode.Items.AddRange(new object[] {
            "LG",
            "MD",
            "MN",
            "SP",
            "ST"});
            this.cboModelCode.Location = new System.Drawing.Point(315, 53);
            this.cboModelCode.Name = "cboModelCode";
            this.cboModelCode.Size = new System.Drawing.Size(121, 45);
            this.cboModelCode.TabIndex = 2;
            // 
            // busBindingSource
            // 
            this.busBindingSource.DataMember = "BusModelBus";
            this.busBindingSource.DataSource = this.busModelBindingSource;
            // 
            // txtMileage
            // 
            this.txtMileage.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.busBindingSource, "Mileage", true));
            this.txtMileage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMileage.Location = new System.Drawing.Point(315, 133);
            this.txtMileage.Name = "txtMileage";
            this.txtMileage.Size = new System.Drawing.Size(250, 44);
            this.txtMileage.TabIndex = 6;
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(647, 131);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(150, 55);
            this.btnSearch.TabIndex = 7;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lstResult
            // 
            this.lstResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstResult.FormattingEnabled = true;
            this.lstResult.ItemHeight = 37;
            this.lstResult.Location = new System.Drawing.Point(75, 263);
            this.lstResult.Name = "lstResult";
            this.lstResult.Size = new System.Drawing.Size(693, 300);
            this.lstResult.TabIndex = 8;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(845, 596);
            this.Controls.Add(this.lstResult);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(mileageLabel);
            this.Controls.Add(this.txtMileage);
            this.Controls.Add(modelCodeLabel);
            this.Controls.Add(this.cboModelCode);
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.busDriverDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.busModelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.busBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BusDriverDataSet busDriverDataSet;
        private System.Windows.Forms.BindingSource busModelBindingSource;
        private BusDriverDataSetTableAdapters.BusModelTableAdapter busModelTableAdapter;
        private BusDriverDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private BusDriverDataSetTableAdapters.BusTableAdapter busTableAdapter;
        private System.Windows.Forms.ComboBox cboModelCode;
        private System.Windows.Forms.BindingSource busBindingSource;
        private System.Windows.Forms.TextBox txtMileage;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ListBox lstResult;
    }
}