﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_9_BusDriverDB
{
    public partial class Form5 : Form
    {
        private List<Candidate> candidateFound = new List<Candidate>();
        private string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\BusDriver.accdb";
        private string _A01 = "A01";
        private string _C55 = "C55";
        private List<int> listDrivers = new List<int>();

        public Form5()
        {
            InitializeComponent();
            btnAddCandidates.Enabled = false;
            btnAssignBuses.Enabled = false;
        }

        private void txtEnterAge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) )
            {
                e.Handled = true;
            }
        }

        private void btnFindCandidates_Click(object sender, EventArgs e)
        {
            lstFindCandidates.Items.Clear();

           OleDbConnection connection = new OleDbConnection(connectionString);

            string selectAge = "SELECT * FROM Candidate WHERE Age < " + txtEnterAge.Text;

            OleDbCommand oleDbCommand = new OleDbCommand(selectAge, connection);

            connection.Open();

            OleDbDataReader reader= oleDbCommand.ExecuteReader();

            if (!reader.HasRows)
            {
                lstFindCandidates.Items.Add("Unable to find Candidate below this age.");
            }
            else
            {
                while (reader.Read())
                {
                    Candidate candidate = new Candidate();
                    candidate.driverID = (int)reader["DriverID"];
                    candidate.name = reader["Name"].ToString();
                    candidate.age = (int)reader["Age"];
                    candidateFound.Add(candidate);
                }
                reader.Close();
                foreach (Candidate a in candidateFound)
                {
                    lstFindCandidates.Items.Add(a.Detail());
                }
                btnFindCandidates.Enabled = false;
                btnAddCandidates.Enabled = true;
            }
            connection.Close();
          
        }

        private void btnAddCandidates_Click(object sender, EventArgs e)
        {
            lstAddCandidates.Items.Clear();
            listDrivers.Clear();
            OleDbConnection connection = new OleDbConnection(connectionString);

            foreach (Candidate candidate in candidateFound)
            {
                string DeleteSql = "Delete from Driver where DriverID =@DriverID;";

                connection.Open();

                OleDbCommand DeleteCommand = new OleDbCommand(DeleteSql, connection);
                DeleteCommand.Parameters.AddWithValue("@DriverID", candidate.driverID);
                DeleteCommand.ExecuteNonQuery();


                listDrivers.Add(candidate.driverID);
                string insertQuery = "INSERT INTO Driver (DriverID, Name, Age, BusNo) " +
                         "VALUES (@DriverID, @name, @age, @BusNo)";
                OleDbCommand insertCommand = new OleDbCommand(insertQuery, connection);
                insertCommand.Parameters.AddWithValue("@DriverID", candidate.driverID);
                insertCommand.Parameters.AddWithValue("@name", candidate.name);
                insertCommand.Parameters.AddWithValue("@age", candidate.age);
                insertCommand.Parameters.AddWithValue("@BusNo", DBNull.Value);
                
                var rowCount = insertCommand.ExecuteNonQuery();

                if (rowCount <= 0)
                {
                    lstAddCandidates.Items.Add("Unable to Add Candidates to the Driver table.");
                    btnAddCandidates.Enabled = false;
                }
                else
                {   
                    var details = string.Format("{0}\t{1}\t{2}\t{3}", 
                        candidate.driverID, candidate.name, candidate.age, DBNull.Value);
                    lstAddCandidates.Items.Add(details);
                }
                connection.Close();

            }
            btnAssignBuses.Enabled = true;
        }

        private void btnAssignBuses_Click(object sender, EventArgs e)
        {
            lstAssignBuses.Items.Clear();
            int thresholdAge = 40;

            //string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\BusDriver.accdb";
            OleDbConnection connection = new OleDbConnection(connectionString);
            string myDrivers = string.Empty;

            foreach (var item in listDrivers)
            {
                myDrivers = myDrivers + item + ",";
            }

            myDrivers = myDrivers.Substring(0, myDrivers.Length - 1);
           

            string sql = "UPDATE Driver SET BusNo = '" + _A01 + "' WHERE Age <= " + thresholdAge + "; " ;
            string  sql1=  "UPDATE Driver SET BusNo = '" + _C55 + "' WHERE Age > " + thresholdAge + "; ";
           string selectSQL =  " SELECT * FROM Driver where DriverID in (" + myDrivers  + ");  ";
                OleDbCommand oleDbCommand1 = new OleDbCommand(sql, connection);
            OleDbCommand oleDbCommand2 = new OleDbCommand(sql1, connection);
            OleDbCommand oleDbCommand3 = new OleDbCommand(selectSQL, connection);

            connection.Open();
             oleDbCommand1.ExecuteNonQuery();
            oleDbCommand2.ExecuteNonQuery();
            OleDbDataReader reader = oleDbCommand3.ExecuteReader();

            if (!reader.HasRows)
            {
                lstAssignBuses.Items.Add("Unable to Assign Candidate to a Bus.");
                btnAssignBuses.Enabled = false;
            }
            else
            {
                while (reader.Read())
                {
                    lstAssignBuses.Items.Add($"{reader[0].ToString()}\t{reader[1].ToString()}\t{reader[2].ToString()}\t{reader[3].ToString()}");

                }
                reader.Close();
            }  
                
            connection.Close();

            // reset form

            txtEnterAge.Text = string.Empty;
            lstFindCandidates.Items.Clear();
            lstAddCandidates.Items.Clear();
            btnFindCandidates.Enabled = true;
           
        }

        //private void Form5_Load(object sender, EventArgs e)
        //{
        //   string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\BusDriver.accdb";
        //}
    }
}
