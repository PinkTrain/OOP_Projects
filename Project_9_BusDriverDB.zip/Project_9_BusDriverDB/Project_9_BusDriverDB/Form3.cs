﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_9_BusDriverDB
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btnBusSummary_Click(object sender, EventArgs e)
        {
            int countBuses = 0;
            int highestMileage = 0;
            int lowestMileage = 0;

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\BusDriver.accdb";
            OleDbConnection connection = new OleDbConnection(connectionString);

            string selectCountBus = "SELECT COUNT(*) FROM Bus";
            OleDbCommand oleDbCommand = new OleDbCommand(selectCountBus, connection);

            string selectHighestMileage = "SELECT MAX(Mileage) FROM Bus";
            OleDbCommand oleDbCommand2 = new OleDbCommand(selectHighestMileage, connection);

            string selectLowestMileage = "SELECT MIN(Mileage) FROM Bus";
            OleDbCommand oleDbCommand3 = new OleDbCommand(selectLowestMileage, connection);

            connection.Open();

            countBuses = (int)oleDbCommand.ExecuteScalar();
            highestMileage = (int)oleDbCommand2.ExecuteScalar();
            lowestMileage = (int)oleDbCommand3.ExecuteScalar();
            
            lblCountBuses.Text = countBuses.ToString();
            lblHighMil.Text = highestMileage.ToString();
            lblLowMil.Text = lowestMileage.ToString();

            connection.Close();
        }

        private void btnDriverSummary_Click(object sender, EventArgs e)
        {
            int countDrivers = 0;
            double aveDriverAge = 0;
            int driversNoBus = 0;

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\BusDriver.accdb";
            OleDbConnection connection = new OleDbConnection(connectionString);
            
            //Queries for Aggregates
            string selectCountDriver = "SELECT COUNT(*) FROM Driver";
            OleDbCommand oleDbCommand3 = new OleDbCommand(selectCountDriver, connection);

            string selectAveDriverAge = "SELECT AVG(Age) FROM Driver";
            OleDbCommand oleDbCommand4 = new OleDbCommand(selectAveDriverAge, connection);

            string selectDriverNoBus = "SELECT COUNT(*) AS NoBusDriver FROM Driver WHERE BusNo IS NULL";
            OleDbCommand oleDbCommand5 = new OleDbCommand(selectDriverNoBus, connection);
            //string selectDriverNoBus = "SELECT SUM(ISNULL(BusNo)) AS NoBusDriver FROM Driver";
            //OleDbCommand oleDbCommand5 = new OleDbCommand(selectDriverNoBus, connection);

            connection.Open();

            countDrivers = (int)oleDbCommand3.ExecuteScalar();
            aveDriverAge = Convert.ToDouble(oleDbCommand4.ExecuteScalar());
            driversNoBus= (int)oleDbCommand5.ExecuteScalar();

            lblCountDrivers.Text = countDrivers.ToString();
            lblAveAge.Text = aveDriverAge.ToString("F2");
            lblNoBus.Text = driversNoBus.ToString();

            connection.Close();
        }
    }
}
