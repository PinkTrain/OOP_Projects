﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_9_BusDriverDB
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void busModelBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.busModelBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.busDriverDataSet);

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'busDriverDataSet.Bus' table. You can move, or remove it, as needed.
            this.busTableAdapter.Fill(this.busDriverDataSet.Bus);
            // TODO: This line of code loads data into the 'busDriverDataSet.BusModel' table. You can move, or remove it, as needed.
            this.busModelTableAdapter.Fill(this.busDriverDataSet.BusModel);

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            lstResult.Items.Clear();

            //list of bus model found
            //List<BusModel> busModelFound = new List<BusModel>();

            //connection string 
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\BusDriver.accdb";
            OleDbConnection connection = new OleDbConnection(connectionString);

            //string selectStatement = string.Format("SELECT * FROM Bus WHERE Model = '{0}' AND Mileage < '{1}'", cboModelCode.Text, txtMileage.Text.ToString());
            string selectStatement = "SELECT * FROM BusModel INNER JOIN Bus ON Bus.Model = BusModel.ModelCode" +
            " WHERE ModelCode = '" + cboModelCode.Text + "' AND Mileage < " + txtMileage.Text;

            OleDbCommand oleDbCommand = new OleDbCommand(selectStatement, connection);
            
            connection.Open();

            OleDbDataReader reader = oleDbCommand.ExecuteReader();

            if (!reader.HasRows)
                lstResult.Items.Add("Invalid model number or no mileage below the specified value.");
            else
                while (reader.Read())
                {
                    var busNo = reader["BusNo"].ToString();
                    var mileage = reader["Mileage"].ToString();
                    var model = reader["Model"].ToString();

                    //return a listbox containing the BusNo, Mileage, Model
                    lstResult.Items.Add(string.Format("{0} - {1} - {2}", busNo, mileage, model));
                }

            connection.Close();
        }      
    }
}
