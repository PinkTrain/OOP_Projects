﻿namespace Project_9_BusDriverDB
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnBusSummary = new System.Windows.Forms.Button();
            this.btnDriverSummary = new System.Windows.Forms.Button();
            this.lblCountBuses = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblHighMil = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblLowMil = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lblNoBus = new System.Windows.Forms.Label();
            this.lblCountDrivers = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblAveAge = new System.Windows.Forms.Label();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.busDriverDataSet = new Project_9_BusDriverDB.BusDriverDataSet();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.busDriverDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBusSummary
            // 
            this.btnBusSummary.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBusSummary.Location = new System.Drawing.Point(177, 389);
            this.btnBusSummary.Name = "btnBusSummary";
            this.btnBusSummary.Size = new System.Drawing.Size(309, 62);
            this.btnBusSummary.TabIndex = 0;
            this.btnBusSummary.Text = "Get Bus Summary";
            this.btnBusSummary.UseVisualStyleBackColor = true;
            this.btnBusSummary.Click += new System.EventHandler(this.btnBusSummary_Click);
            // 
            // btnDriverSummary
            // 
            this.btnDriverSummary.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDriverSummary.Location = new System.Drawing.Point(782, 389);
            this.btnDriverSummary.Name = "btnDriverSummary";
            this.btnDriverSummary.Size = new System.Drawing.Size(309, 62);
            this.btnDriverSummary.TabIndex = 1;
            this.btnDriverSummary.Text = "Get Driver Summary";
            this.btnDriverSummary.UseVisualStyleBackColor = true;
            this.btnDriverSummary.Click += new System.EventHandler(this.btnDriverSummary_Click);
            // 
            // lblCountBuses
            // 
            this.lblCountBuses.AutoSize = true;
            this.lblCountBuses.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountBuses.ForeColor = System.Drawing.Color.Blue;
            this.lblCountBuses.Location = new System.Drawing.Point(361, 63);
            this.lblCountBuses.Name = "lblCountBuses";
            this.lblCountBuses.Size = new System.Drawing.Size(27, 29);
            this.lblCountBuses.TabIndex = 3;
            this.lblCountBuses.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(109, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "Total Buses:";
            // 
            // lblHighMil
            // 
            this.lblHighMil.AutoSize = true;
            this.lblHighMil.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHighMil.ForeColor = System.Drawing.Color.Blue;
            this.lblHighMil.Location = new System.Drawing.Point(361, 128);
            this.lblHighMil.Name = "lblHighMil";
            this.lblHighMil.Size = new System.Drawing.Size(27, 29);
            this.lblHighMil.TabIndex = 5;
            this.lblHighMil.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(74, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(216, 31);
            this.label3.TabIndex = 4;
            this.label3.Text = "Highest Mileage:";
            // 
            // lblLowMil
            // 
            this.lblLowMil.AutoSize = true;
            this.lblLowMil.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLowMil.ForeColor = System.Drawing.Color.Blue;
            this.lblLowMil.Location = new System.Drawing.Point(361, 193);
            this.lblLowMil.Name = "lblLowMil";
            this.lblLowMil.Size = new System.Drawing.Size(27, 29);
            this.lblLowMil.TabIndex = 7;
            this.lblLowMil.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(65, 190);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(210, 31);
            this.label5.TabIndex = 6;
            this.label5.Text = "Lowest Mileage:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.lblLowMil);
            this.groupBox1.Controls.Add(this.lblCountBuses);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.lblHighMil);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(62, 109);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(503, 254);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "About Buses:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.lblNoBus);
            this.groupBox2.Controls.Add(this.lblCountDrivers);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.lblAveAge);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(654, 109);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(551, 240);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "About Drivers:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(155, 60);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(177, 31);
            this.label6.TabIndex = 2;
            this.label6.Text = "Total Drivers:";
            // 
            // lblNoBus
            // 
            this.lblNoBus.AutoSize = true;
            this.lblNoBus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoBus.ForeColor = System.Drawing.Color.Blue;
            this.lblNoBus.Location = new System.Drawing.Point(390, 189);
            this.lblNoBus.Name = "lblNoBus";
            this.lblNoBus.Size = new System.Drawing.Size(30, 31);
            this.lblNoBus.TabIndex = 7;
            this.lblNoBus.Text = "0";
            // 
            // lblCountDrivers
            // 
            this.lblCountDrivers.AutoSize = true;
            this.lblCountDrivers.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountDrivers.ForeColor = System.Drawing.Color.Blue;
            this.lblCountDrivers.Location = new System.Drawing.Point(390, 62);
            this.lblCountDrivers.Name = "lblCountDrivers";
            this.lblCountDrivers.Size = new System.Drawing.Size(30, 31);
            this.lblCountDrivers.TabIndex = 3;
            this.lblCountDrivers.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(79, 189);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(253, 31);
            this.label9.TabIndex = 6;
            this.label9.Text = "Drivers with no bus:\r\n";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(155, 122);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(175, 31);
            this.label10.TabIndex = 4;
            this.label10.Text = "Average age:";
            // 
            // lblAveAge
            // 
            this.lblAveAge.AutoSize = true;
            this.lblAveAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAveAge.ForeColor = System.Drawing.Color.Blue;
            this.lblAveAge.Location = new System.Drawing.Point(390, 122);
            this.lblAveAge.Name = "lblAveAge";
            this.lblAveAge.Size = new System.Drawing.Size(30, 31);
            this.lblAveAge.TabIndex = 5;
            this.lblAveAge.Text = "0";
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataSource = this.busDriverDataSet;
            this.bindingSource1.Position = 0;
            // 
            // busDriverDataSet
            // 
            this.busDriverDataSet.DataSetName = "BusDriverDataSet";
            this.busDriverDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1291, 550);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnDriverSummary);
            this.Controls.Add(this.btnBusSummary);
            this.Name = "Form3";
            this.Text = "Form3";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.busDriverDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBusSummary;
        private System.Windows.Forms.Button btnDriverSummary;
        private System.Windows.Forms.Label lblCountBuses;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.BindingSource bindingSource1;
        private BusDriverDataSet busDriverDataSet;
        private System.Windows.Forms.Label lblHighMil;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblLowMil;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblNoBus;
        private System.Windows.Forms.Label lblCountDrivers;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblAveAge;
    }
}