﻿namespace Project_9_BusDriverDB
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label busNoLabel;
            System.Windows.Forms.Label mileageLabel;
            System.Windows.Forms.Label modelLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.busBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.busBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.busNoTextBox = new System.Windows.Forms.TextBox();
            this.mileageTextBox = new System.Windows.Forms.TextBox();
            this.modelComboBox = new System.Windows.Forms.ComboBox();
            this.busBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.busDriverDataSet = new Project_9_BusDriverDB.BusDriverDataSet();
            this.busTableAdapter = new Project_9_BusDriverDB.BusDriverDataSetTableAdapters.BusTableAdapter();
            this.tableAdapterManager = new Project_9_BusDriverDB.BusDriverDataSetTableAdapters.TableAdapterManager();
            busNoLabel = new System.Windows.Forms.Label();
            mileageLabel = new System.Windows.Forms.Label();
            modelLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.busBindingNavigator)).BeginInit();
            this.busBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.busBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.busDriverDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // busNoLabel
            // 
            busNoLabel.AutoSize = true;
            busNoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            busNoLabel.Location = new System.Drawing.Point(154, 114);
            busNoLabel.Name = "busNoLabel";
            busNoLabel.Size = new System.Drawing.Size(132, 37);
            busNoLabel.TabIndex = 1;
            busNoLabel.Text = "Bus No:";
            // 
            // mileageLabel
            // 
            mileageLabel.AutoSize = true;
            mileageLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            mileageLabel.Location = new System.Drawing.Point(154, 194);
            mileageLabel.Name = "mileageLabel";
            mileageLabel.Size = new System.Drawing.Size(136, 37);
            mileageLabel.TabIndex = 3;
            mileageLabel.Text = "Mileage:";
            // 
            // modelLabel
            // 
            modelLabel.AutoSize = true;
            modelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            modelLabel.Location = new System.Drawing.Point(154, 275);
            modelLabel.Name = "modelLabel";
            modelLabel.Size = new System.Drawing.Size(112, 37);
            modelLabel.TabIndex = 5;
            modelLabel.Text = "Model:";
            // 
            // busBindingNavigator
            // 
            this.busBindingNavigator.AddNewItem = null;
            this.busBindingNavigator.BindingSource = this.busBindingSource;
            this.busBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.busBindingNavigator.DeleteItem = null;
            this.busBindingNavigator.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.busBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.busBindingNavigatorSaveItem});
            this.busBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.busBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.busBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.busBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.busBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.busBindingNavigator.Name = "busBindingNavigator";
            this.busBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.busBindingNavigator.Size = new System.Drawing.Size(590, 39);
            this.busBindingNavigator.TabIndex = 0;
            this.busBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(71, 36);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(36, 36);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(36, 36);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 39);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 39);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(36, 36);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(36, 36);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // busBindingNavigatorSaveItem
            // 
            this.busBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.busBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("busBindingNavigatorSaveItem.Image")));
            this.busBindingNavigatorSaveItem.Name = "busBindingNavigatorSaveItem";
            this.busBindingNavigatorSaveItem.Size = new System.Drawing.Size(36, 36);
            this.busBindingNavigatorSaveItem.Text = "Save Data";
            this.busBindingNavigatorSaveItem.Click += new System.EventHandler(this.busBindingNavigatorSaveItem_Click);
            // 
            // busNoTextBox
            // 
            this.busNoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.busBindingSource, "BusNo", true));
            this.busNoTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.busNoTextBox.Location = new System.Drawing.Point(301, 108);
            this.busNoTextBox.Name = "busNoTextBox";
            this.busNoTextBox.Size = new System.Drawing.Size(121, 44);
            this.busNoTextBox.TabIndex = 2;
            // 
            // mileageTextBox
            // 
            this.mileageTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.busBindingSource, "Mileage", true));
            this.mileageTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mileageTextBox.Location = new System.Drawing.Point(301, 188);
            this.mileageTextBox.Name = "mileageTextBox";
            this.mileageTextBox.Size = new System.Drawing.Size(121, 44);
            this.mileageTextBox.TabIndex = 4;
            // 
            // modelComboBox
            // 
            this.modelComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.busBindingSource, "Model", true));
            this.modelComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modelComboBox.FormattingEnabled = true;
            this.modelComboBox.Location = new System.Drawing.Point(301, 267);
            this.modelComboBox.Name = "modelComboBox";
            this.modelComboBox.Size = new System.Drawing.Size(121, 45);
            this.modelComboBox.TabIndex = 6;
            // 
            // busBindingSource
            // 
            this.busBindingSource.DataMember = "Bus";
            this.busBindingSource.DataSource = this.busDriverDataSet;
            // 
            // busDriverDataSet
            // 
            this.busDriverDataSet.DataSetName = "BusDriverDataSet";
            this.busDriverDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // busTableAdapter
            // 
            this.busTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BusModelTableAdapter = null;
            this.tableAdapterManager.BusTableAdapter = this.busTableAdapter;
            this.tableAdapterManager.CandidateTableAdapter = null;
            this.tableAdapterManager.DriverTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Project_9_BusDriverDB.BusDriverDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(590, 406);
            this.Controls.Add(busNoLabel);
            this.Controls.Add(this.busNoTextBox);
            this.Controls.Add(mileageLabel);
            this.Controls.Add(this.mileageTextBox);
            this.Controls.Add(modelLabel);
            this.Controls.Add(this.modelComboBox);
            this.Controls.Add(this.busBindingNavigator);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.busBindingNavigator)).EndInit();
            this.busBindingNavigator.ResumeLayout(false);
            this.busBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.busBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.busDriverDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BusDriverDataSet busDriverDataSet;
        private System.Windows.Forms.BindingSource busBindingSource;
        private BusDriverDataSetTableAdapters.BusTableAdapter busTableAdapter;
        private BusDriverDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator busBindingNavigator;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton busBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox busNoTextBox;
        private System.Windows.Forms.TextBox mileageTextBox;
        private System.Windows.Forms.ComboBox modelComboBox;
    }
}