﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_9_BusDriverDB
{
    class Candidate
    {
        public int driverID { get; set; }
        public string name { get; set; }
        public int age { get; set; }

        public string Detail()
        {
            return driverID.ToString() + "\t" + name + "\t" + age.ToString();
        }
    }
}
