﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilesToLINQ
{
    public class Employee
    {
        public int Emp_ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Dept_ID { get; set; }
        //public string Proj { get; set; }
        //public string Title { get; set; }
        //public DateTime StartDate { get; set; }
    }
}
