﻿namespace FilesToLINQ
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnReadTxt = new System.Windows.Forms.Button();
            this.btnEmployeeProj = new System.Windows.Forms.Button();
            this.btnMinBudget = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnReadTxt
            // 
            this.btnReadTxt.Location = new System.Drawing.Point(237, 140);
            this.btnReadTxt.Name = "btnReadTxt";
            this.btnReadTxt.Size = new System.Drawing.Size(887, 47);
            this.btnReadTxt.TabIndex = 0;
            this.btnReadTxt.Text = "Read emp.txt, project.txt, projectempl.text from C:\\Exam3\r\n";
            this.btnReadTxt.UseVisualStyleBackColor = true;
            this.btnReadTxt.Click += new System.EventHandler(this.btnReadTxt_Click);
            // 
            // btnEmployeeProj
            // 
            this.btnEmployeeProj.Location = new System.Drawing.Point(237, 229);
            this.btnEmployeeProj.Name = "btnEmployeeProj";
            this.btnEmployeeProj.Size = new System.Drawing.Size(887, 47);
            this.btnEmployeeProj.TabIndex = 1;
            this.btnEmployeeProj.Text = "Display in a messagebox details of employees who works on projects\r\n";
            this.btnEmployeeProj.UseVisualStyleBackColor = true;
            this.btnEmployeeProj.Click += new System.EventHandler(this.btnEmployeeProj_Click);
            // 
            // btnMinBudget
            // 
            this.btnMinBudget.Location = new System.Drawing.Point(237, 320);
            this.btnMinBudget.Name = "btnMinBudget";
            this.btnMinBudget.Size = new System.Drawing.Size(887, 51);
            this.btnMinBudget.TabIndex = 2;
            this.btnMinBudget.Text = "Find manager and analyst from d1, d2, and d3 with project budget $150K min\r\n";
            this.btnMinBudget.UseVisualStyleBackColor = true;
            this.btnMinBudget.Click += new System.EventHandler(this.btnMinBudget_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1360, 523);
            this.Controls.Add(this.btnMinBudget);
            this.Controls.Add(this.btnEmployeeProj);
            this.Controls.Add(this.btnReadTxt);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnReadTxt;
        private System.Windows.Forms.Button btnEmployeeProj;
        private System.Windows.Forms.Button btnMinBudget;
    }
}

