﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FilesToLINQ
{
    public partial class Form1 : Form
    {
        private static string dir = @"C:\Exam3\";
        private static string path = dir + "Emp.txt";
        private static string path2 = dir + "Proj.txt";
        private static string path3 = dir + "ProjEmp.txt";

       List<Employee> employees = new List<Employee>();
       List<Project> projects = new List<Project>();
       List<EmployeeWithProj> employeesProj = new List<EmployeeWithProj>();

        FileStream fs = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnReadTxt_Click(object sender, EventArgs e)
        {
            if (!Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            fs = new FileStream(path, FileMode.Open, FileAccess.Read);
            StreamReader textIn = new StreamReader(fs);
            while (textIn.Peek() != -1)
            {
                string row = textIn.ReadLine();
                string[] columns = row.Split('*');
                Employee employee = new Employee();
                employee.Emp_ID = int.Parse(columns[0]);
                employee.FirstName = columns[1];
                employee.LastName = columns[2];
                employee.Dept_ID = columns[3];
                employees.Add(employee);
            }

            fs = new FileStream(path2, FileMode.Open, FileAccess.Read);
            StreamReader textIn2 = new StreamReader(fs);
            while (textIn2.Peek() != -1)
            {
                string row = textIn2.ReadLine();
                string[] columns = row.Split('*');
                Project project = new Project();
                project.Proj_ID = columns[0];
                project.Proj_Name = columns[1];
                project.Budget = int.Parse(columns[2]);
                projects.Add(project);
            }

            fs = new FileStream(path3, FileMode.Open, FileAccess.Read);
            StreamReader textIn3 = new StreamReader(fs);

            while (textIn3.Peek() != -1)
            {
                string row = textIn3.ReadLine();
                string[] columns = row.Split('*');
                EmployeeWithProj employee2 = new EmployeeWithProj();
                employee2.Emp_ID = int.Parse(columns[0]);
                employee2.Proj = columns[1];
                employee2.Title = columns[2];
                employee2.StartDate = Convert.ToDateTime(columns[3]);
                employeesProj.Add(employee2);
            }
            MessageBox.Show("All files were read.");

            textIn.Close();
        }

        private void btnEmployeeProj_Click(object sender, EventArgs e)
        {
            var qryEmployee  = from emp in employees
                               join emproj in employeesProj on emp.Emp_ID equals emproj.Emp_ID
                               where emproj.Proj != null
                               select emproj;

            MessageBox.Show(qryEmployee.ToString());  
        }

        private void btnMinBudget_Click(object sender, EventArgs e)
        {
            //var qry = from employee
        }
    }
}
