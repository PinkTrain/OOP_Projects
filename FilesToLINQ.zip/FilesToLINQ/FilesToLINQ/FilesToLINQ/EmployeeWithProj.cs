﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilesToLINQ
{
    public class EmployeeWithProj
    {
        public int Emp_ID { get; set; }
        public string Proj { get; set; }
        public string Title { get; set; }
        public DateTime StartDate { get; set; }
    }
}
