﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilesToLINQ
{
    public class Project
    {
        public string Proj_ID { get; set; }
        public string Proj_Name { get; set; }
        public int Budget { get; set; }
    }
}
