﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace DBtoFile
{
    public partial class Form1 : Form
    {
        private string connectionString = "Data Source=laptop-ugqiahug;Initial Catalog=MMABooks;Integrated Security=True";
        private List<Product> productFound = new List<Product>();
        private List<Product> products = new List<Product>();
        //bool p = true;
        string @p = " ";
        private static string dir = @"C:\Exam3";
        private static string path = dir + "Products.txt";
        FileStream fs = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            string selectQry = txtSelectQry.Text + " WHERE UnitPrice = " + @p;
            if (txtUnitPrice.Text == " ")
            {
                p =  txtUnitPrice.Text;
            }

            SqlCommand selectCommand = new SqlCommand(selectQry, connection);
            connection.Open();

            SqlDataReader reader = selectCommand.ExecuteReader();
        
            if (!reader.HasRows)
            {
                MessageBox.Show("Unable to find Product with this price.");
            }
            else
            {
                while (reader.Read())
                {
                    Product product = new Product();
                    product.productCode = reader["ProductCoded"].ToString();
                    product.description = reader["Description"].ToString();
                    product.unitPrice = (decimal)reader["UnitPrice"];
                    productFound.Add(product);
                }

                lblRowsCount.Text = productFound.Count.ToString();
               
            }
        }

        private void btnSavetoFile_Click(object sender, EventArgs e)
        {
            fs = new FileStream(path, FileMode.Create, FileAccess.Write);
            StreamWriter textOut = new StreamWriter(fs);

            foreach (Product product in products)
            {
                textOut.Write(product.productCode + "|");
                textOut.Write(product.description + "|");
                textOut.Write(product.unitPrice + "|");
            }

            textOut.Close();
        }
    }
}
